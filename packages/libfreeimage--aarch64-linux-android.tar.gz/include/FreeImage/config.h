// use static lib
#define FREEIMAGE_LIB

/* #undef SUPPORT_FMT_WEBP */

/* #undef SUPPORT_FMT_JPEG */

/* #undef SUPPORT_FMT_OPENEXR */

/* #undef SUPPORT_FMT_TIFF */

/* #undef SUPPORT_FMT_JXR */
